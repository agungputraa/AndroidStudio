package com.wanda.agungproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Informasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informasi);
    }
}